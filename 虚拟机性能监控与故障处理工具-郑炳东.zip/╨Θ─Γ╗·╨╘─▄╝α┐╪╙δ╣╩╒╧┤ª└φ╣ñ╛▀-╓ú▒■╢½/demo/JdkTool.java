package com.example.demo.jdkTool;

import java.util.Map;
import java.util.Scanner;

/**
 * @ClassName JdkTool
 * @Description TODO
 * @author
 * @date 2020/8/26 19:47
 */
public class JdkTool {


    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        sc.next();
    }

//    public static void main(String[] args) {
//        Map<Thread, StackTraceElement[]> m = Thread.getAllStackTraces();
//
//        for (Map.Entry<Thread, StackTraceElement[]> en : m.entrySet()){
//            Thread t = en.getKey();
//            StackTraceElement[] v = en.getValue();
//
//            System.out.println("The Thread name is :" + t.getName());
//            for (StackTraceElement s : v){
//                System.err.println("\t" + s.toString());
//            }
//        }
//
//    }



}
